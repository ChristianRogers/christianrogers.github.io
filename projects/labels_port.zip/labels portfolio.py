import openpyxl
import tkinter as tk
from tkinter.filedialog import askopenfilename, asksaveasfilename
from tkinter import messagebox
from docx import Document
from docx.enum.table import WD_ROW_HEIGHT_RULE
from docx.shared import Inches, Pt
from datetime import datetime

FIRSTNAME_INDEX = 2
LASTNAME_INDEX = 3

ADDRESS_INDEX = 4
CITY_STATE_ZIP_INDEX = 5

def open_file_dialog():
    #Imports XLSX file using the OS file explorer and returns the file
    print("Attempting to open file dialog...")
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.lift()
    root.focus_force()
    file = askopenfilename(parent=root, title="Select an excel file", filetypes=[("Excel Spreadsheets", "*.xlsx *.xls *.xlsm")])
    root.destroy()
    return file

def save_file_dialog():
    #Saves the DOCX file using the OS file explorer and returns the file path
    print("Attempting to open save file dialog...")
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.lift()
    root.focus_force()
    file_path = asksaveasfilename(parent=root, title="Where would you like to save the labels?", defaultextension=".docx", initialfile=f"{datetime.now().strftime('%Y-%m-%d')} Labels.docx", filetypes=[("Word Documents", "*.docx, *.doc,")])
    root.destroy()
    return file_path

def read_file(filename=None):
    if filename and filename.endswith(('.xlsx', '.xls', '.xlsm')):
        print(f"Selected: {filename}")
        sheet = openpyxl.load_workbook(filename, data_only=True).active
        data = []
        for row in sheet.iter_rows(values_only=True):
            data.append(row)
        return data
    else:
        print("No valid file selected.")
        return []
    
def safe_get(row, index):
    try:
        #does data exist at that index
        if index < len(row):
            val = row[index]
            if val is None: #This avoids errors if the cell is empty, like the word "none" appearing
                return ""
            return str(val).strip()
        else:
            return ""
    except IndexError:
        print (f"IndexError: Tried to access index {index} in row {row}, but it doesn't exist.")
        return ""
    
def clean_address(address):

    if "," in address:
        #Cleans address string by removing unwanted characters or formatting
        address_parts = [part.strip() for part in address.split(',') if part.strip()]
        address = '\n'.join(address_parts)
        return address.strip()
    else:
        return address.strip()

def clean_city_state_zip(city_state_zip):
    if not city_state_zip:
        return ""
    #Makes sure city is in title case, but state is all caps, and zip is correct
    city_name = ""
    state_and_zip = ""
    parts = city_state_zip.split(',', 1) 
    city_name = (parts[0].title().strip())
    state_and_zip = parts[-1].strip()
    
    return f"{city_name}, {state_and_zip}"

    
def write_to_word(data, filename):
    if data:
        data.pop(0)  # Removes header row
    else:
        print("No data to write.")
        return
    
    doc = Document()
    #TODO: Set page margins as specified in example doc
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(0)
        section.left_margin = Inches(0.3)
        section.right_margin = Inches(0.19)


    #TODO: Set font to Times New Roman, size 12, line spacing 1.0
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    paragraph_format = style.paragraph_format
    paragraph_format.line_spacing = 1.0
    paragraph_format.space_after = Pt(0)


    table = doc.add_table(rows=0, cols=3) #Makes a table, so the doc is in three columns
    table.autofit = False 

    table.columns[0].width = Inches(2.7)
    table.columns[1].width = Inches(2.7)
    table.columns[2].width = Inches(2.7)
    MIN_ROW_HEIGHT = Inches(1)

    for index, row in enumerate(data):
        #Add a new row every 3 labels, about what we are able to fit on a page
        if index % 3 == 0:
           new_row = table.add_row()
           new_row.height = MIN_ROW_HEIGHT
           new_row.height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
        
        current_row_cells = table.rows[-1].cells
        #Figures out which cell to put the data in
        cell = current_row_cells[index % 3]

        #Gets the data from the imported xls list safely in title case
        fname = safe_get(row, FIRSTNAME_INDEX).title()
        lname = safe_get(row, LASTNAME_INDEX).title()
        address = clean_address(safe_get(row, ADDRESS_INDEX).title())
        city_state_zip = clean_city_state_zip(safe_get(row, CITY_STATE_ZIP_INDEX))

        #Adds the label information to the cell
        cell.text = f"{fname} {lname}\n{address}\n{city_state_zip}\n"

    doc.save(filename)

def main():
    excel_file = open_file_dialog()
    data = read_file(excel_file)
    if not data or len(data) <= 1:
        messagebox.showerror("Error", "No data to write.")
        return
    
    save_file = save_file_dialog()
    if save_file:
        write_to_word(data, save_file)
        
        #success dialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showinfo("Success", f"Labels created successfully!\nSaved to: {save_file}")
        root.destroy()

    else:
        messagebox.showerror("Error", "No file selected to save labels.")


if __name__ == "__main__":
    main()
